Slopechart 1 is for slider selection
Slopechart 2 is for histogram selection