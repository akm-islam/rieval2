import React from 'react';
import { makeStyles } from '@material-ui/core/styles';
import "./TopBar.scss";
import TextField from '@material-ui/core/TextField';
import Autocomplete from '@material-ui/lab/Autocomplete';
import * as d3 from 'd3';
import DefaultModels from './DefaultModels'
import Sort from './Sort'
import { connect } from "react-redux";
import Grid from '@material-ui/core/Grid';
import Button from '@material-ui/core/Button';
import * as algo1 from "../../Algorithms/algo1"
const useStyles = makeStyles((theme) => ({
  MuiAutocompleteroot: {
    marginTop: 0,
  },
  root: {
    width: '100%',
  },
  listroot: {
    width: '100%',
    maxWidth: 360,
  },
  paper: {
  },
  heading: {
    fontSize: theme.typography.pxToRem(15),
    fontWeight: theme.typography.fontWeightRegular,
  },
}));
function TopBar(props) {
  const classes = useStyles();
  const handleyearChange = (event, value, reason) => {
    if (reason == 'select-option') {
      props.Set_selected_year(value)
      var myfunc = props.appHandleChange
      myfunc(value, "year_changed")
    }
  };
  return (
    props.mode != "Time" ?
      <Grid container spacing={0} className="Topbar_parent">
        <Grid item style={{ borderRight: "1px dashed #eaeaea", width: 100, height: 35 }}><Button>Filters:</Button></Grid>
        <div className="year" style={{ borderRight: "1px dashed #eaeaea", width: 120, height: 35, marginTop: 3 }}>
          <Autocomplete className={{ root: classes.MuiAutocompleteroot }}
            defaultValue={props.selected_year.toString()}
            id="debug"
            debug
            options={props.years_for_dropdown.map((option) => option)}
            renderInput={(params) => (
              <TextField {...params} label="" margin="normal" fullWidth={true} InputProps={{ ...params.InputProps, disableUnderline: true }} />
            )}
            onChange={(event, value, reason) => {
              handleyearChange(event, value, reason)
              props.Set_histogram_data([]) // This is because the histogram data is calculated within a range if the range is changed after the selection, it throws error
              props.Set_changed("year")
              props.Set_slider_max(props.grouped_by_year_data[value].length)
              //------Check if selected state is out of range for Model mode
              var selected_by_year_data = props.grouped_by_year_data[value]
              if(props.mode=="Model"){
              var temp_selected_states = []
              selected_by_year_data.map(item0 => {
                props.clicked_items_in_slopechart.map(item => { if (item.substring(1) == item0['State'].replace(/ +/g, "")) { temp_selected_states.push(parseInt((item0['two_realRank']))) } })
              })
              var temp_state_range = [...props.state_range]
              if (temp_state_range[0] >= d3.min(temp_selected_states)) { temp_state_range[0] = d3.min(temp_selected_states) }
              if (temp_state_range[1] <= d3.max(temp_selected_states)) { temp_state_range[1] = d3.max(temp_selected_states) }
              props.Set_state_range(temp_state_range)
            }
              //------Check if selected state is out of range ends here

              //------Check if selected state is out of range for Range mode
              if(props.mode=="Range"){
              var temp_selected_states_range1 = []
              selected_by_year_data.map(item0 => {
                props.clicked_items_in_slopechart.map(item => { if (item.substring(1) == item0['State'].replace(/ +/g, "")) { temp_selected_states_range1.push(parseInt((item0['two_realRank']))) } })
              })
              var temp_state_range = [...props.range_mode_range1]
              if (temp_state_range[0] >= d3.min(temp_selected_states_range1)) { temp_state_range[0] = d3.min(temp_selected_states_range1) }
              if (temp_state_range[1] <= d3.max(temp_selected_states_range1)) { temp_state_range[1] = d3.max(temp_selected_states_range1) }
              props.Set_range_mode_range1(temp_state_range)
              //-----Range2
              var temp_selected_states_range2 = []
              selected_by_year_data.map(item0 => {
                props.clicked_items_in_slopechart.map(item => { if (item.substring(1) == item0['State'].replace(/ +/g, "")) { temp_selected_states_range2.push(parseInt((item0['two_realRank']))) } })
              })
              var temp_state_range = [...props.range_mode_range2]
              if (temp_state_range[0] >= d3.min(temp_selected_states_range2)) { temp_state_range[0] = d3.min(temp_selected_states_range2) }
              if (temp_state_range[1] <= d3.max(temp_selected_states_range2)) { temp_state_range[1] = d3.max(temp_selected_states_range2) }
              props.Set_range_mode_range2(temp_state_range)
            }
            if(props.mode=="Time"){
              var temp_selected_states_time = []
              selected_by_year_data.map(item0 => {
                props.clicked_items_in_slopechart.map(item => { if (item.substring(1) == item0['State'].replace(/ +/g, "")) { temp_selected_states.push(parseInt((item0['two_realRank']))) } })
              })
              var temp_state_range = [...props.time_mode_range]
              if (temp_state_range[0] >= d3.min(temp_selected_states)) { temp_state_range[0] = d3.min(temp_selected_states_time) }
              if (temp_state_range[1] <= d3.max(temp_selected_states)) { temp_state_range[1] = d3.max(temp_selected_states_time) }
              props.Set_time_mode_range(temp_state_range)
            }
            //------Check if selected state is out of range ends here
            var temp_Models = algo1.sort(props.sort_by, props.state_range, props.default_models,value, props.grouped_by_year_data)[0];
            var default_model_scores=algo1.sort(props.sort_by, props.state_range, props.default_models,value, props.grouped_by_year_data)[1];
            props.Set_default_model_scores(default_model_scores)
            props.Set_default_models(temp_Models)
            props.Set_pop_over_models(temp_Models)
            }
            }
          />
        </div>
        {props.mode == "Model" ? <div><div><DefaultModels appHandleChange={props.appHandleChange}></DefaultModels></div>
          <div><Sort appHandleChange={props.appHandleChange}></Sort></div></div> : null}
 
      </Grid> : null
  );
}
const maptstateToprop = (state) => {
  return {
    tracking: state.tracking,
    selected_year: state.selected_year,
    years_for_dropdown: state.years_for_dropdown,
    default_models: state.default_models,
    mode: state.mode,
    prev_prop: state.prev_prop,
    state_range: state.state_range,
    replay: state.replay,
    grouped_by_year_data: state.grouped_by_year_data,
    clicked_items_in_slopechart: state.clicked_items_in_slopechart,
    range_mode_range1: state.range_mode_range1,
    range_mode_range2: state.range_mode_range2,
    time_mode_range: state.time_mode_range,
    mode: state.mode, // Model mode model
    sort_by: state.sort_by,

  }
}
const mapdispatchToprop = (dispatch) => {
  return {
    add: (val) => dispatch({ type: "add", value: val }),
    Set_selected_year: (val) => dispatch({ type: "selected_year", value: val }),
    set_tracking: (val) => dispatch({ type: "tracking", value: val }),
    Set_histogram_data: (val) => dispatch({ type: "histogram_data", value: val }),
    Set_changed: (val) => dispatch({ type: "changed", value: val }),
    Set_state_range: (val) => dispatch({ type: "state_range", value: val }),
    Set_slider_max: (val) => dispatch({ type: "slider_max", value: val }),
    Set_range_mode_range1: (val) => dispatch({ type: "range_mode_range1", value: val }),
    Set_range_mode_range2: (val) => dispatch({ type: "range_mode_range2", value: val }),
    Set_time_mode_range: (val) => dispatch({ type: "time_mode_range", value: val }),
    Set_pop_over_models: (val) => dispatch({ type: "pop_over_models", value: val }),
    Set_default_models: (val) => dispatch({ type: "default_models", value: val }),
    Set_default_model_scores: (val) => dispatch({ type: "default_model_scores", value: val }),
  }
}
export default connect(maptstateToprop, mapdispatchToprop)(TopBar);

//https://material-ui.com/api/slider/
//https://material-ui.com/components/expansion-panels/
//https://material-ui.com/api/checkbox/
//https://material-ui.com/components/radio-buttons/